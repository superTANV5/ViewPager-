/** Automatically generated file. DO NOT MODIFY */
package com.example.appdetail_optimization;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}